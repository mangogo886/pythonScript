#!/bin/bash

cd /data/prideploy/ng

for file in `find sites-available -type f`
do
cd /data/prideploy/ng/sites-enabled
ln -s ../$file
done
