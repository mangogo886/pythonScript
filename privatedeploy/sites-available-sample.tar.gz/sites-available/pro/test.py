#!/usr/bin/env python
#coding:utf-8

import os

filenames=open('files').readlines()
for file in filenames:
    file=file.strip()
    os.popen("sed -i '/        listen 80;/a\        listen 443 ssl;' %s" %file)
    os.popen("sed -i '/        error_page 405 =200 $uri;/a\        ' %s" %file)
    os.popen("sed -i '/        /a\        ssl_certificate \/etc\/nginx\/sslkey\/qky100\/qky100.pem;' %s" %file)
    os.popen("sed -i '/        ssl_certificate \/etc\/nginx\/sslkey\/qky100\/qky100.pem;/a\        ssl_certificate_key     \/etc\/nginx\/sslkey\/qky100\/qky100.key;' %s" %file)
    os.popen("sed -i '/        ssl_certificate_key     \/etc\/nginx\/sslkey\/qky100\/qky100.key;/a\        ssl_session_timeout 5m;' %s"%file)
    os.popen("sed -i '/        ssl_session_timeout 5m;/a\        ssl_protocols TLSv1 TLSv1.1 TLSv1.2;' %s" %file)
    os.popen("sed -i '/        ssl_protocols TLSv1 TLSv1.1 TLSv1.2;/a\        ssl_ciphers AESGCM:ALL:!DH:!EXPORT:!RC4:+HIGH:!MEDIUM:!LOW:!aNULL:!eNULL;' %s" %file)
    os.popen("sed -i '/        ssl_ciphers AESGCM:ALL:!DH:!EXPORT:!RC4:+HIGH:!MEDIUM:!LOW:!aNULL:!eNULL;/a\        ssl_prefer_server_ciphers on;' %s"%file)
