:title: API reference

API reference
=============

.. automodule:: jenkins
    :members:
    :undoc-members:

.. automodule:: jenkins.plugins
    :members:
    :noindex:
    :undoc-members:
